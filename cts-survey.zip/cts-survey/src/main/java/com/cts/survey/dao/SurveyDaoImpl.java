package com.cts.survey.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;

@Repository
@Transactional
public class SurveyDaoImpl implements SurveyDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	/*final String query = "select * from SURVEY_QUESTION";
	final String insertTeamLeadQuery = "update PROJECTLEAD_INFO set QUESTION_ID=?,VALUE=? where PL_EMAIL_ID=?";
	final String insertTMQuery = "update TMMEMBER_INFO set QUESTION_ID = ?,VALUE=? where TM_EMAIL_ID=?";
	final String insertPartInfo ="INSERT INTO PARTICIPANTS_INFO(ROLE,EMAIL_ID,PL_UNIQUE_ID,TM_UNIQUE_ID) VALUES (?,?,?,?)";
	final String selRoleFromPl= "SELECT A.ROLE FROM projectlead_info A WHERE A.PL_EMAIL_ID=?";
	final String selRoleFromTM= "SELECT A.ROLE FROM TMMEMBER_INFO A WHERE A.TM_EMAIL_ID=?";
	//final String insertTMInfo = "insert into TMMEMBER_INFO(TM_EMAIL_ID,PL_EMAIL_ID,ROLE,PL_UNIQUE_ID) values(?,?,?,?)";
	final String insertTMInfo = "INSERT INTO ctssurvey.TMMEMBER_INFO(TM_EMAIL_ID,ROLE,PL_UNIQUE_ID) VALUES (?,?,?)";*/
	
	
	final String query = "select * from SURVEY_QUESTION";
	final String insertTeamLeadQuery = "update PROJECTLEAD_INFO set QUESTION_ID=?,VALUE=? where PL_EMAIL_ID=?";
	final String insertTMQuery = "update TMMEMBER_INFO set QUESTION_ID = ?,VALUE=? where TM_EMAIL_ID=?";
	final String insertPartInfo ="INSERT INTO PARTICIPANTS_INFO(ROLE,EMAIL_ID,PL_UNIQUE_ID,TM_UNIQUE_ID) VALUES (?,?,?,?)";
	final String selRoleFromPl= "SELECT A.ROLE FROM projectlead_info A WHERE A.PL_EMAIL_ID=?";
	final String selRoleFromTM= "SELECT A.ROLE FROM TMMEMBER_INFO A WHERE A.TM_EMAIL_ID=?";
	final String insertTMInfo = "INSERT INTO TMMEMBER_INFO(TM_EMAIL_ID,ROLE,PL_UNIQUE_ID) VALUES (?,?,?)";
	
	@Override
	public List<Row> getQuestion() {
		// TODO Auto-generated method stub
		
		List<Row> rows = jdbcTemplate.query(query, new RowMapper() {

			@Override
			public Row mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Row row = new Row();
				row.setQuestion(rs.getString("QUESTION"));
				row.setQuestion_id(rs.getString("QUESTION_ID"));
				return row;
			}
		});
		return rows;
	}

	@Override
	public int insertData(ContactForm form, StringBuilder qstn,StringBuilder ans,String emails) {
		// TODO Auto-generated method stub

		KeyHolder holder = new GeneratedKeyHolder();
		if(form.getRole().equals("PL")) {
			jdbcTemplate.update(new PreparedStatementCreator() {           
	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTeamLeadQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2, ans.toString());
	                ps.setString(3,form.getEmail());
	                
	                return ps;
	            }
	        }, holder);
			int id = jdbcTemplate.queryForObject("select pl_unique_id from projectlead_info where pl_email_id=?",new Object[]{form.getEmail()},Integer.class);
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),id,""});
			
			String[] emailList;
			if (emails.contains(";")) {
				emailList = emails.split(";");
			} else {
				emailList = new String[] {emails};
			}
			
			for (String email : emailList) {
				//jdbcTemplate.update(insertTMInfo,new Object[]{email,form.getEmail(),"TM",id});
				jdbcTemplate.update(insertTMInfo,new Object[]{email,"TM",id});
			}
			
			
		} else {
			
			jdbcTemplate.update(new PreparedStatementCreator() {           

	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTMQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2,ans.toString() );
	                ps.setString(3,form.getEmail());
	                
	                return ps;
	            }
	        }, holder);
			int id = jdbcTemplate.queryForObject("select TM_UNIQUE_ID from TMMEMBER_INFO where TM_EMAIL_ID=?",new Object[]{form.getEmail()},Integer.class);
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),null,id});
		}
		return 0;
	}

	@Override
	public String getRole(String emailId) {
		// TODO Auto-generated method stub
		
		List<String> roleList = null;
		
		roleList = jdbcTemplate.queryForList(selRoleFromPl, new Object[] {emailId},String.class);
		
		if(roleList!=null && roleList.size()==0) {
			roleList = jdbcTemplate.queryForList(selRoleFromTM, new Object[] {emailId},String.class);
		}
		
		if (roleList ==null) {
			return  null;
		}
		if ( roleList.size()>0) {
			return roleList.get(0);
		} else {
			return null;
		}
		
	}

}
