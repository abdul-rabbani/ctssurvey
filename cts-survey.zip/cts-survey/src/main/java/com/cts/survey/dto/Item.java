package com.cts.survey.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Item {
	
	  @JsonProperty("name")
	  private String name;
	  
	  @JsonProperty("title")
	  private String title;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	  
	  

}
