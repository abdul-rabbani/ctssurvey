package com.cts.survey.service;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.*;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.ow2.bonita.connector.impl.email.SMTPAuthenticator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cts.survey.controller.AdminController;
import com.cts.survey.repository.AdminDAO;
import com.sun.mail.util.MailSSLSocketFactory;

@Service
public class SurveyService {
	
	private static final Logger logger = LoggerFactory.getLogger(SurveyService.class);
	
	//@Autowired
	// SurveyDAO surveyDAO;
	
	//@Autowired
	//SurveyRepository surveyRepository;
	
	//@Autowired
	//MemberRepository memberRepository;
	
	//@Autowired
	//TeamMemberInfoRepository memberRepository;
	
	@Autowired
	AdminDAO adminDAO;
	
	@Value("${senderEmailID}")
	private  String senderEmailID;
	@Value("${senderEmailPassword}")
	private  String senderEmailPassword;
	@Value("${mailPort}")
	private  String mailPort;
	@Value("${mail.smtp.host}")
	private  String hostName;
	@Value("${mail.body.tm}")
	private  String mailTmBody;
	
	private  String fileName = "Survey_";
	private static final String filePath = "sample.csv";
	
	@Value("${mail.body.survey}")
	private  String mailbody;
	

	//Get PL emailIds
	public List<String> getEmailInfo(){
		//List<ProjectLeadInfo> leadInfo = surveyRepository.findAll();
		List<String> plInfo = adminDAO.getProjectLeads();
		return plInfo;
	}
	//save PL emailIds
    public void saveEmailIds(String role,String emailId){
		List<String> emailIds = new LinkedList<String>();
		//List<ProjectLeadInfo> leadInfo = new LinkedList<ProjectLeadInfo>();
		//ProjectLeadInfo info = new ProjectLeadInfo();
		if(emailId.contains(";")) {
			 
			String str[] = emailId.split(";");
			emailIds = Arrays.asList(str);
			for(String mailId :emailIds ) {
				adminDAO.insertProjectLeads(mailId);
				//info = new ProjectLeadInfo();
				 //info.setRole("PL");
				// info.setEmailId(mailId);
				//leadInfo.add(info);
			}
		}else {
			// info.setRole("PL");
			 //info.setEmailId(emailId);
			 //leadInfo.add(info);
			//leadInfo.add(info);
			emailIds.add(emailId);
			adminDAO.insertProjectLeads(emailId);
		}
		
		//surveyRepository.saveAll(leadInfo);
		//surveyDAO.saveEmailIds(role,emailIds);
		
		if(emailIds != null && !emailIds.isEmpty()) {
			String body =  "<html>"
					+ "<head>"
					+ "</head>"
					+ "<body>"
					+"<font color='blue'>"
					+ "Hi,<br/> Please Complete the Survey before due date. </b>"
					+"</font>"
					+ "</body>"
					+ "</html>";
			for(String receipientEmailID :emailIds) {
			try {
				SendMail(receipientEmailID,"Invitation for Survey", mailbody, true, filePath, fileName);
  				
			//	SendMail(receipientEmailID.getEmailId(),"Cognizant Survey", body, true, filePath, fileName);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			}
		
	}
    
    
  //Get TM emailIds
  	public List<String> getTMEmailInfo(String plemailid){
  		//List<TeamMemberInfo> memberInfo = memberRepository.findAll();
  		//List<TeamMemberInfo> memberInfo = new ArrayList<TeamMemberInfo>();
  		 return adminDAO.getTeamMembers(plemailid);
  	}
  	
  	//save TM emailIds
      public void saveTMEmailIds(String role,String emailId,String plEmailId){
  		List<String> emailIds = new LinkedList<String>();
  		//List<TeamMemberInfo> memberInfo = new LinkedList<TeamMemberInfo>();
  		//TeamMemberInfo info = new TeamMemberInfo();
  		if(emailId.contains(";")) {
  			 
  			String str[] = emailId.split(";");
  			emailIds = Arrays.asList(str);
  			for(String mailId :emailIds) {
  				/*info = new TeamMemberInfo();
  				 info.setRole("TM");
  				 info.setEmailId(mailId);
  				info.setpLemailId(plEmailId);
  				memberInfo.add(info);*/
  				adminDAO.insertTeamMembers(mailId, plEmailId);
  			}
  		}else {
  			 //info.setRole("TM");
  			 //info.setEmailId(emailId);
  			 //info.setpLemailId(plEmailId);
  			//memberInfo.add(info);
  			adminDAO.insertTeamMembers(emailId, plEmailId);
  		}
  		
  		//memberRepository.saveAll(memberInfo);
      }
      
      public void sendMailToMembers(String memberMailId) {
    	  
    	  if(memberMailId.contains(";")) {
 			 
  			String str[] = memberMailId.split(";");
  			List<String> memberMailIds = Arrays.asList(str);
    	  if(memberMailIds != null && !memberMailIds.isEmpty()) {
  			String body =  "<html>"
  					+ "<head>"
  					+ "</head>"
  					+ "<body>"
  					+"<font color='blue'>"
  					+ "Hi,<br/> Please find the survey link  </b>"
  					+"</font>"
  					+ "</body>"
  					+ "</html>";
  			for(String receipientEmailID :memberMailIds) {
  			try {
  				SendMail(receipientEmailID,"Invitation for Survey", mailbody, true, filePath, fileName);
  				//SendMail(receipientEmailID, "Invitation for Survey ",mailTmBody, true);
  			}   catch (MessagingException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  			}
  			}
    	  }
    	  
    	  
      }
    
    
  
  /* public List<String> getTLEmails(String emailId){
	   List<String> tlEmailList = new LinkedList<String>();
	   tlEmailList.add("employee1@cognizant.com");
	   tlEmailList.add("employee2@cognizant.com");
	   tlEmailList.add("employee3@cognizant.com");
	   tlEmailList.add("employee4@cognizant.com");
		return tlEmailList;
   }*/
   
	public void deleteTables() {
		System.out.println("===============Delete Tables=Data==============");
		adminDAO.deleteData();
		 
	}
   
	public  void SendMail(
            String receipientEmailID,
            String subject,
            String body,
            boolean isHtmlBody,
            String filePath,
            String fileName) throws MessagingException {

        SMTPAuthenticator auth = new SMTPAuthenticator(senderEmailID, senderEmailPassword);

        MailSSLSocketFactory sf;
		try {
			sf = new MailSSLSocketFactory();
			sf.setTrustAllHosts(true);
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

        Properties props = new Properties();
        props.put("mail.smtp.host", hostName);    
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", mailPort);  
        
        logger.info("mailport"+mailPort +"senderEmailID" +senderEmailID +"receipientEmailID" +receipientEmailID);

        Session session = Session.getInstance(props, auth);
        session.setDebug(true);

        MimeMessage message = new MimeMessage(session);

        try {
			message.setFrom(new InternetAddress(senderEmailID, "Cognizant survey team"));
			 message.setRecipient(Message.RecipientType.TO, new InternetAddress(receipientEmailID));
		     message.setRecipient(Message.RecipientType.CC, new InternetAddress(senderEmailID));
		    message.setSubject(subject);
		} catch (UnsupportedEncodingException | MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       

//            MimeBodyPart mbp = new MimeBodyPart();
//            if (isHtmlBody) {
//                mbp.setContent(body, "text/html");
//            }
//
//            message.setText(body);
        // Create the message part 
        BodyPart messageBodyPart = new MimeBodyPart();
        // Fill the message 
        if (isHtmlBody) {
            try {
				messageBodyPart.setContent(body, "text/html; charset=utf-8");
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } else {
            try {
				messageBodyPart.setText(body);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        // Create a Multipart 
        Multipart multipart = new MimeMultipart();
        // Add part one
        try {
			multipart.addBodyPart(messageBodyPart);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // // Part two is attachment // // Create second body part 
        messageBodyPart = new MimeBodyPart();
        // Get the attachment 
        DataSource source = new FileDataSource(filePath);
        // Set the data handler to the attachment 
        try {
			messageBodyPart.setDataHandler(new DataHandler(source));
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the filename
        messageBodyPart.setFileName(fileName);
        // Add part two 
        multipart.addBodyPart(messageBodyPart);
        // Put parts in message
        message.setContent(multipart);

        System.out.println("Before Sending...");
        try {
        Transport.send(message);
        }catch(Exception e) {
        	logger.debug(e.getMessage());
        	e.printStackTrace();
        	logger.error(e.getMessage());
        }
        System.out.println("Mail Send.");
    }
	
	private List<String>  getPLEmailIds() {
		
		
		List<String>  emailList = new LinkedList<String>();
		for(int i =1; i<=51; i++) {
		emailList.add("ProjectLead"+i+"@gmail.com");
		}
		 
		
		return emailList;
		
		
	}
	public  Map<String,List<String>> getEmailDetails(){
		
		List<String>  plList = getPLEmailIds();
		List<String>  tmlist =  new LinkedList<String>();
		Map<String,List<String>> map = new HashMap<String,List<String>>();
		
		for(int i =1; i<=11; i++) {
			tmlist.add("TeamMember"+i+"@gmail.com");
			}
		
		for(String email:plList) {
			
			map.put(email, tmlist);
			
		}
		
 System.out.println("map" +map);		
		
		return map;
		
		
	}

}
