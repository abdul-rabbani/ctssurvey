package com.cts.survey.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.ow2.bonita.connector.impl.email.SMTPAuthenticator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.survey.dao.SurveyDao;
import com.cts.survey.dto.Pages;
import com.cts.survey.form.ContactForm;
import com.cts.survey.service.QuestionPageService;
import com.cts.survey.service.SurveyService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.mail.util.MailSSLSocketFactory;



@Controller
public class SurveyController {
	private static final Logger logger = LoggerFactory.getLogger(SurveyController.class);
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	//private  String fileName = "Survey_";
	//private static final String filePath = "sample.csv";
	
	/*@Value("${senderEmailID}")
	private  String senderEmailID;
	@Value("${senderEmailPassword}")
	private  String senderEmailPassword;
	@Value("${mailPort}")
	private  String mailPort;
	@Value("${mail.smtp.host}")
	private  String hostName;
	@Value("${mail.body.tm}")
	private  String mailTmBody;*/
	
	@Autowired
	QuestionPageService questionPageService;
	
	@Autowired
	SurveyService surveyService;
	
	
	
	@RequestMapping("/")
	public String takeMeToHome() {
		return "welcomePage";
	}
	
	  @RequestMapping("/takesurvey")
	    public String survey(HttpSession session) {
	        if (session.getAttribute("error") != null) {
	            session.setAttribute("error",null);
	        }
	        return "surveyindex";
	 }
	
	@RequestMapping("/emaillist")
	public ModelAndView emailList() {
		Map<String,List<String>> emailList = surveyService.getEmailDetails();
		ModelAndView mav = new ModelAndView();
        mav.addObject("emailList", emailList);
        mav.setViewName("EmailDetailsList");
		return mav;
	}
	
	
	@RequestMapping("/startSurvey")
	public String takeMeToSurvey(ContactForm contactForm,HttpSession session) throws JsonProcessingException {
		
		session.setAttribute("contactForm", contactForm);
		String email = contactForm.getEmail();
		String role = questionPageService.getRole(email);
		String status = questionPageService.getStatus(email);
		if (role == null) {
			session.setAttribute("error", "You are not applicable for this survey");
			return "surveyindex";
		} else {
			contactForm.setRole(role);
		}
		 if(status !=null && status.equals("C")) {
	            System.out.println("Survey has been done ....");
	            session.setAttribute("error", "You are done with this survey. Thank you!");
	            return "surveyindex";
	        } else if(status !=null && status.equals("P")) {
	            //to do for resume case
	        }
//		ObjectMapper objectMapper = new ObjectMapper();
//		
//		
//		session.setAttribute("pages", objectMapper.writeValueAsString(pages));
		System.out.println(contactForm.getEmail());
		return "survey";
	}
	
	@RequestMapping("/endSurvey")
	public String endSurvey(HttpSession session,@RequestParam(name="jsonField") String json) throws JsonProcessingException, IOException, GeneralSecurityException, MessagingException {
		
		
		System.out.println(json);
		ContactForm form = (ContactForm)session.getAttribute("contactForm");
		
		questionPageService.insertDetails(json, form);
			
		return "surveyindex";
	}
  
  
	
    /*public  void SendMail(
            String receipientEmailID,
            String subject,
            String body,
            boolean isHtmlBody) throws GeneralSecurityException, MessagingException, UnsupportedEncodingException {

        SMTPAuthenticator auth = new SMTPAuthenticator(senderEmailID, senderEmailPassword);

        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);

        Properties props = new Properties();
        props.put("mail.smtp.host", hostName);    
        
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", mailPort);  

        Session session = Session.getInstance(props, auth);
        session.setDebug(false);

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(senderEmailID, "Cognizant survey team"));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(receipientEmailID));
        message.setRecipient(Message.RecipientType.CC, new InternetAddress(senderEmailID));
        message.setSubject(subject);

        if (isHtmlBody) {
            message.setContent(body, "text/html; charset=utf-8");
        } else {
            message.setText(body);
        }

        System.out.println("Before Sending...");
        Transport.send(message);
        System.out.println("Mail Send.");
    }

	public  void SendMail(
            String receipientEmailID,
            String subject,
            String body,
            boolean isHtmlBody,
            String filePath,
            String fileName) throws GeneralSecurityException, MessagingException, UnsupportedEncodingException {

        SMTPAuthenticator auth = new SMTPAuthenticator(senderEmailID, senderEmailPassword);

        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);

        Properties props = new Properties();
        props.put("mail.smtp.host", hostName);    
           
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", mailPort);  

        Session session = Session.getInstance(props, auth);
        session.setDebug(true);

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(senderEmailID, "Cognizant survey team"));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(receipientEmailID));
        message.setRecipient(Message.RecipientType.CC, new InternetAddress(senderEmailID));
        message.setSubject(subject);

//            MimeBodyPart mbp = new MimeBodyPart();
//            if (isHtmlBody) {
//                mbp.setContent(body, "text/html");
//            }
//
//            message.setText(body);
        // Create the message part 
        BodyPart messageBodyPart = new MimeBodyPart();
        // Fill the message 
        if (isHtmlBody) {
            messageBodyPart.setContent(body, "text/html; charset=utf-8");
        } else {
            messageBodyPart.setText(body);
        }
        // Create a Multipart 
        Multipart multipart = new MimeMultipart();
        // Add part one
        multipart.addBodyPart(messageBodyPart);
        // // Part two is attachment // // Create second body part 
        messageBodyPart = new MimeBodyPart();
        // Get the attachment 
        DataSource source = new FileDataSource(filePath);
        // Set the data handler to the attachment 
        messageBodyPart.setDataHandler(new DataHandler(source));
        // Set the filename
        messageBodyPart.setFileName(fileName);
        // Add part two 
        multipart.addBodyPart(messageBodyPart);
        // Put parts in message
        message.setContent(multipart);

        System.out.println("Before Sending...");
        Transport.send(message);
        System.out.println("Mail Send.");
    }*/

}
