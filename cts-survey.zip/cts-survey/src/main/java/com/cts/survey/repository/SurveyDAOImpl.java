package com.cts.survey.repository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.cts.survey.form.EmailList;

@Repository
public class SurveyDAOImpl implements SurveyDAO{

	@Override
	public void saveEmailIds(String role,List<String> emailIds) {
		System.out.println("inside saveEmailIds Impl"+role +"emailid"+emailIds);
		
	}
	@Override
	public List<String> getEmailIds(String role,List<String> emailIds) {
		System.out.println("inside getEmailIds DAO Impl"+role);
		System.out.println("emailIds getEmailIds DAO Impl"+emailIds);
		List<String> emaillist = new ArrayList<String>();
		if(emailIds != null && !emailIds.isEmpty()) {
			//EmailList emailList = new EmailList();
			for(String emailId : emailIds) {
		
			}
		}
		return emailIds;
	}
	
	@Override
	@Cacheable(value = "teamemails", key="#requestedrole")
	public List<String> getTeamEmailIds(String requestedrole) {
		System.out.println("inside getTeamEmailIds DAO Impl"+requestedrole);
		List<String> teamEmailList = new LinkedList<String>();
		teamEmailList.add("employee1@cognizant.com");
		teamEmailList.add("employee2@cognizant.com");
		teamEmailList.add("employee3@cognizant.com");
		teamEmailList.add("employee4@cognizant.com");
		return teamEmailList;
	}

}
