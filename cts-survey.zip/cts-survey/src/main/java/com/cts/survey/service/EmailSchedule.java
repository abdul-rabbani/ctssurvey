package com.cts.survey.service;


import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component
@EnableScheduling
public class EmailSchedule {
	
	private static final Logger logger = LoggerFactory.getLogger(EmailSchedule.class);
	
	@Autowired
	private SurveyService service;
	 
	//@Scheduled(cron = "0 0 0 * * ?") //sec min hr date mnth
	@Scheduled(cron = "${scheduletime}")
	public void emailRemainderJob() {
		 logger.info("Current time is :: " + Calendar.getInstance().getTime());
		 service.sendRemainderMail();
		
	}

}
