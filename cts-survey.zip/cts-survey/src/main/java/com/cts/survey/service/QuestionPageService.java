package com.cts.survey.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.survey.dao.SurveyDao;
import com.cts.survey.dto.Column;
import com.cts.survey.dto.Item;
import com.cts.survey.dto.Page;
import com.cts.survey.dto.Pages;
import com.cts.survey.dto.Question;
import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class QuestionPageService {
	
	@Autowired
	SurveyDao surveyDao;
	@Value("${question.page.size}")
	int pageSize;
	//@Value("${input.html}")
	//String html;
	
	public Pages getQuestions(String role) throws Exception {
		
		List<Column> columnsList = new LinkedList<Column>();
		Column column = new Column();
		column.setText("Strongly Disagree");
		column.setValue(1);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Disagree");
		column.setValue(2);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Likely Disagree");
		column.setValue(3);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Neither agree/disagree");
		column.setValue(4);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Likely Agree");
		column.setValue(5);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Agree");
		column.setValue(6);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Strongly Agree");
		column.setValue(7);
		columnsList.add(column);
			
		
		List<Row> rows = surveyDao.getQuestion(role);
		System.out.println("Question list size "+rows.size());
		
		List<Page> pageList = new LinkedList<Page>();
		
		
		if (rows.size()>0) {
			int pos= pageSize;
			int top= 0;
			while(pos<= rows.size()) {
				
				List<Row> rowList = rows.subList(top, pos);
				List<Question> questions = new LinkedList<Question>();
				for (Row row : rowList) {
					Question question = new Question();
					question.setType("matrix");
					question.setName(row.getQuestion_id());
					question.setTitle(row.getQuestion());
					question.setColumns(columnsList);
					questions.add(question);
				}
				
				
				
				
				
				
				Page page = new Page();
				page.setQuestions(questions);
				pageList.add(page);
				top=pos;
				if (pos==rows.size()) {
					break;
				}
				pos = pos + pageSize;
				if (pos>rows.size()) {
					
					pos = rows.size();
				}
				System.out.println("pos "+pos +" top" +top);
			}
			
			Page page1 = new Page();
			List<Question> questions1 = new LinkedList<Question>();
			Question question1 = new Question();
			List<String> choices = new ArrayList();
			choices.add("Male");
			choices.add("Female");
			choices.add("Other");
			question1.setChoices(choices);
			question1.setType("dropdown");
			question1.setName("Gender");
			question1.setTitle("Gender");
			question1.setColumns(columnsList);
			questions1.add(question1);
			
			question1 = new Question();
			choices = new ArrayList();
			for (int i=10;i<100;i++) {
			choices.add(i+" Yrs");
			}
			question1.setChoices(choices);
			question1.setType("dropdown");
			question1.setName("Age");
			question1.setTitle("Age");
			question1.setColumns(columnsList);
			questions1.add(question1);
			
			question1 = new Question();
			
			Item itemMonth = new Item();
			itemMonth.setName("Month");
			itemMonth.setTitle("Month");
			Item itemYear = new Item();
			itemYear.setName("Year");
			itemYear.setTitle("Year");
			
			List<Item> itemList = new ArrayList();
			itemList.add(itemMonth);
			itemList.add(itemYear);
			
			question1.setType("multipletext");
			question1.setName("Experience");
			question1.setTitle("IT Indutry Work Experience");
			question1.setItems(itemList);
			question1.setColCount(2);
			questions1.add(question1);
			
			
			question1 = new Question();
			itemMonth = new Item();
			itemMonth.setName("Month");
			itemMonth.setTitle("Month");
			itemYear = new Item();
			itemYear.setName("Year");
			itemYear.setTitle("Year");
			
			itemList = new ArrayList();
			itemList.add(itemMonth);
			itemList.add(itemYear);
			
			question1.setType("multipletext");
			question1.setName("Current Company");
			question1.setTitle("Years of Experience in Current Company");
			question1.setItems(itemList);
			question1.setColCount(2);
			questions1.add(question1);
			
			question1 = new Question();
			
			itemMonth = new Item();
			itemMonth.setName("Month");
			itemMonth.setTitle("Month");
			itemYear = new Item();
			itemYear.setName("Year");
			itemYear.setTitle("Year");
			
			itemList = new ArrayList();
			itemList.add(itemMonth);
			itemList.add(itemYear);
			
			question1.setType("multipletext");
			question1.setName("current Project");
			question1.setTitle("Time spent in current Project");
			question1.setItems(itemList);
			question1.setColCount(2);
			if (role.equals("L")) {
				
				
				question1 = new Question();
				
				itemMonth = new Item();
				itemMonth.setName("Month");
				itemMonth.setTitle("Month");
				itemYear = new Item();
				itemYear.setName("Year");
				itemYear.setTitle("Year");
				
				itemList = new ArrayList();
				itemList.add(itemMonth);
				itemList.add(itemYear);
				
				
				question1.setType("multipletext");
				question1.setName("project is running");
				question1.setTitle("Years since this project is running");
				question1.setItems(itemList);
				question1.setColCount(2);
				questions1.add(question1);
			
			}
			question1 = new Question();
			choices = new ArrayList();
//			for (int i=1;i<50;i++) {
//				choices.add(i+" Yrs");
//			}
			choices.add("PG");
			choices.add("UG");
			
			question1.setChoices(choices);
			question1.setType("dropdown");
			question1.setName("Education Level");
			question1.setTitle("Education Level");
			question1.setColumns(columnsList);
			questions1.add(question1);
			
			if (role.equals("L")) {
				question1 = new Question();
				
				itemMonth = new Item();
				itemMonth.setName("Month");
				itemMonth.setTitle("Month");
				itemYear = new Item();
				itemYear.setName("Year");
				itemYear.setTitle("Year");
				
				itemList = new ArrayList();
				itemList.add(itemMonth);
				itemList.add(itemYear);
				
				question1.setType("multipletext");
				question1.setName("Tenure");
				question1.setTitle("Average Tenure of Team members in team");
				question1.setItems(itemList);
				question1.setColCount(2);
				questions1.add(question1);
			}
			
			if (role.equals("M")) {
				question1 = new Question();
				itemMonth = new Item();
				itemMonth.setName("Month");
				itemMonth.setTitle("Month");
				itemYear = new Item();
				itemYear.setName("Year");
				itemYear.setTitle("Year");
				
				itemList = new ArrayList();
				itemList.add(itemMonth);
				itemList.add(itemYear);
				
				question1.setType("multipletext");
				question1.setName("Tenure with current Team Lead");
				question1.setTitle("Tenure with current Team Lead");
				question1.setItems(itemList);
				question1.setColCount(2);
				questions1.add(question1);
			}
			
			
			page1.setQuestions(questions1);
			pageList.add(page1);
			
			
		} else {
			throw new Exception("No question found");
		}
		
		
		
		
		//next page
//		if (role.equals("PL")) {
//			Question question1 = new Question();
//			question1.setType("text");
//			question1.setName("email");
//			question1.setTitle("Thank you for taking our survey. Your survey is almost complete, please enter your email address in the box below if you wish to participate in our drawing, then press the 'Submit' button.");
//			List<Question> questions1 = new LinkedList<>();
//			questions1.add(question1);
//			
//			Page page1 = new Page();
//			page1.setQuestions(questions1);	
//			pageList.add(page1);
//			//end here
//		}
		
		
		Pages pages = new Pages();
		pages.setPages(pageList);
		pages.setTitle("Cognizant Survey Feedback question");
		pages.setShowProgressBar("top");
		
		return pages;
		
		
	}
	
	@Transactional
	public void insertDetails(String json,ContactForm form) throws JsonProcessingException, IOException {
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = mapper.readTree(json);
		String email = "";
//		if (form.getRole().equals("PL")) {
//			JsonNode emails = node.findValue("email");
//			email = emails.asText();
//		}
		Iterator<Entry<String,JsonNode>> it  =  node.fields();
		StringBuilder qstn = new  StringBuilder();
		StringBuilder ans = new  StringBuilder();
		
		
		while (it.hasNext()) {
			Map.Entry<String, JsonNode> qstnAnswerMap1 = it.next();
			
			String key =qstnAnswerMap1.getKey();
			if(!key.equals("Quality")) {
				if(qstn.length()!=0) {
					qstn.append(",");
				}
				qstn.append(key);
				
				if(ans.length()!=0) {
					ans.append(",");
				}
				ans.append(qstnAnswerMap1.getValue());
				
			}
			Iterator<Entry<String,JsonNode>> questionsIt  =  qstnAnswerMap1.getValue().fields();
			while (questionsIt.hasNext()) {
				Map.Entry<String, JsonNode> qstnAnswerMap = questionsIt.next();
				
				if(qstn.length()!=0) {
					qstn.append(",");
				}
				qstn.append(qstnAnswerMap.getKey());
				
				
				if(ans.length()!=0) {
					ans.append(",");
				}
				ans.append(qstnAnswerMap.getValue());
				
				
				
				System.out.println("Key"+qstnAnswerMap.getKey()+"VALUE " +qstnAnswerMap.getValue());
			}
		}
		
		System.out.println(qstn.toString() + " : "+ ans.toString());
		surveyDao.insertData(form, qstn, ans,email);
	}
	
	public String getRole(String emailId) {
		return  surveyDao.getRole(emailId);
	}
	
	public String getStatus(String emailId) {
		return  surveyDao.checkSurveyStatus(emailId);
	}

}
