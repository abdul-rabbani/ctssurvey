package com.cts.survey.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.ow2.bonita.connector.impl.email.SMTPAuthenticator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cts.survey.dao.SurveyDao;
import com.cts.survey.dto.Pages;
import com.cts.survey.form.ContactForm;
import com.cts.survey.form.LoginForm;
import com.cts.survey.model.ProjectLeadInfo;
import com.cts.survey.model.TeamMemberInfo;
import com.cts.survey.service.QuestionPageService;
import com.cts.survey.service.SurveyService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.mail.util.MailSSLSocketFactory;



@Controller
public class SurveyController {
	private static final Logger logger = LoggerFactory.getLogger(SurveyController.class);
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	//private  String fileName = "Survey_";
	//private static final String filePath = "sample.csv";
	
	/*@Value("${senderEmailID}")
	private  String senderEmailID;
	@Value("${senderEmailPassword}")
	private  String senderEmailPassword;
	@Value("${mailPort}")
	private  String mailPort;
	@Value("${mail.smtp.host}")
	private  String hostName;
	@Value("${mail.body.tm}")
	private  String mailTmBody;*/
	
	 
	@Value("${loginid}")
	private  String adminUserId;
	
	@Value("${password}")
	private  String password;
	
	@Value("${app-name}")
	private String appName;
	
	@Value("${welcomemessage}")
	private String welcomemessage;
	
	@Autowired
	QuestionPageService questionPageService;
	
	@Autowired
	SurveyService surveyService;
	
	
	
	@RequestMapping("/")
	public ModelAndView takeMeToHome() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("appname", appName);
		mav.setViewName("adminlogin");
		//return "welcomePage";
		return mav;
	}
	
	@RequestMapping("/surveylogin")
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("appname", appName);
		mav.setViewName("surveylogin");
		//return "welcomePage";
		return mav;
		//return "surveylogin";
	}
	
	@RequestMapping("/admin")
	public ModelAndView emailList(LoginForm loginform,HttpSession session) {
		ModelAndView mav = new ModelAndView();
	 
		System.out.println(session.getAttribute("username"));
		System.out.println(adminUserId);
	    if(!adminUserId.equals(loginform.getUser()) && !password.equals(loginform.getPassword())) {
			mav.addObject("loginerror", "Username or Password is Invalid.");
			session.setAttribute("loginerror", "Username or Password is Invalid.");
			 mav.addObject("appname", appName);
			mav.setViewName("adminlogin");
			return mav;
		}
		Map<ProjectLeadInfo,List<TeamMemberInfo>> emailList = surveyService.getEmailDetails();
		session.setAttribute("loginform", loginform);
		 session.setAttribute("username", adminUserId);
		 session.setAttribute("appname", appName);
		 session.setAttribute("loginerror", null);
        mav.addObject("emailList", emailList);
        mav.addObject("appname", appName);
        mav.setViewName("EmailDetailsList");
		return mav;
	}
	
	
	@RequestMapping("/surveystatus")
	public ModelAndView surveyStatus(LoginForm loginform,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		Map<ProjectLeadInfo,List<TeamMemberInfo>> emailList = surveyService.getEmailDetails();
		//session.setAttribute("username", userName);
		//session.setAttribute("loginform", loginform);
        mav.addObject("emailList", emailList);
        mav.addObject("appname", appName);
        session.setAttribute("username", adminUserId);
		 session.setAttribute("appname", appName);
        mav.setViewName("surveystatus");
		return mav;
	}
	
	@RequestMapping("/home")
	public ModelAndView adminHome(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		Map<ProjectLeadInfo,List<TeamMemberInfo>> emailList = surveyService.getEmailDetails();
		//session.setAttribute("loginform", loginform);
		 session.setAttribute("username", adminUserId);
		 session.setAttribute("appname", appName);
		 session.setAttribute("loginerror", null);
        mav.addObject("emailList", emailList);
        mav.addObject("appname", appName);
        mav.setViewName("EmailDetailsList");
		return mav;
	}
	
	  //Send mail to  Team member and PL
	@PostMapping("/sendemail")
	public @ResponseBody String sendMail(@RequestParam("emailid") String emailid) {
		System.out.println("emailids contoller" + emailid);
		String message = surveyService.sendMailToAll(emailid);
		return message;
	}
	
	
	  @RequestMapping("/takesurvey")
	    public String survey(HttpSession session) {
		  if (session.getAttribute("error") != null) {
              session.setAttribute("error",null);
          }
		  
	        session.setAttribute("appname", appName);
	        session.setAttribute("welcomemessage", welcomemessage);
	        
	       // return "surveyindex";
	        return "surveywelcome";
	 }
	  
	  @RequestMapping("/prepareSurvey")
	  public String prepareSurvey(HttpSession session) {
	        if (session.getAttribute("error") != null) {
	            session.setAttribute("error",null);
	        }
	        
	       return "surveyindex";
	        
	      
	 }
	  
	  
	
	@RequestMapping("/startSurvey")
	public String takeMeToSurvey(ContactForm contactForm,HttpSession session) throws JsonProcessingException {
		
		session.setAttribute("contactForm", contactForm);
		session.setAttribute("appname", appName);
		String email = contactForm.getEmail();
		String role = questionPageService.getRole(email);
		String status = questionPageService.getStatus(email);
		if (role == null) {
			session.setAttribute("error", "You are not applicable for this survey");
			return "surveyindex";
			 
		} else {
			contactForm.setRole(role);
		}
		 if(status !=null && status.equals("C")) {
	            System.out.println("Survey has been done ....");
	            session.setAttribute("error", "You are done with this survey. Thank you!");
	            return "surveyindex";
	           
	        } else if(status !=null && status.equals("P")) {
	            //to do for resume case
	        }
//		ObjectMapper objectMapper = new ObjectMapper();
//		
//		
//		session.setAttribute("pages", objectMapper.writeValueAsString(pages));
		System.out.println(contactForm.getEmail());
		return "survey";
	}
	
	@RequestMapping("/endSurvey")
	public String endSurvey(HttpSession session,@RequestParam(name="jsonField") String json) throws JsonProcessingException, IOException, GeneralSecurityException, MessagingException {
		
		
		System.out.println(json);
		ContactForm form = (ContactForm)session.getAttribute("contactForm");
		session.setAttribute("appname", appName);
		questionPageService.insertDetails(json, form);
			
		return "surveyindex";
	}
  
  
	
    /*public  void SendMail(
            String receipientEmailID,
            String subject,
            String body,
            boolean isHtmlBody) throws GeneralSecurityException, MessagingException, UnsupportedEncodingException {

        SMTPAuthenticator auth = new SMTPAuthenticator(senderEmailID, senderEmailPassword);

        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);

        Properties props = new Properties();
        props.put("mail.smtp.host", hostName);    
        
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", mailPort);  

        Session session = Session.getInstance(props, auth);
        session.setDebug(false);

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(senderEmailID, "Cognizant survey team"));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(receipientEmailID));
        message.setRecipient(Message.RecipientType.CC, new InternetAddress(senderEmailID));
        message.setSubject(subject);

        if (isHtmlBody) {
            message.setContent(body, "text/html; charset=utf-8");
        } else {
            message.setText(body);
        }

        System.out.println("Before Sending...");
        Transport.send(message);
        System.out.println("Mail Send.");
    }

	public  void SendMail(
            String receipientEmailID,
            String subject,
            String body,
            boolean isHtmlBody,
            String filePath,
            String fileName) throws GeneralSecurityException, MessagingException, UnsupportedEncodingException {

        SMTPAuthenticator auth = new SMTPAuthenticator(senderEmailID, senderEmailPassword);

        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);

        Properties props = new Properties();
        props.put("mail.smtp.host", hostName);    
           
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", mailPort);  

        Session session = Session.getInstance(props, auth);
        session.setDebug(true);

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(senderEmailID, "Cognizant survey team"));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(receipientEmailID));
        message.setRecipient(Message.RecipientType.CC, new InternetAddress(senderEmailID));
        message.setSubject(subject);

//            MimeBodyPart mbp = new MimeBodyPart();
//            if (isHtmlBody) {
//                mbp.setContent(body, "text/html");
//            }
//
//            message.setText(body);
        // Create the message part 
        BodyPart messageBodyPart = new MimeBodyPart();
        // Fill the message 
        if (isHtmlBody) {
            messageBodyPart.setContent(body, "text/html; charset=utf-8");
        } else {
            messageBodyPart.setText(body);
        }
        // Create a Multipart 
        Multipart multipart = new MimeMultipart();
        // Add part one
        multipart.addBodyPart(messageBodyPart);
        // // Part two is attachment // // Create second body part 
        messageBodyPart = new MimeBodyPart();
        // Get the attachment 
        DataSource source = new FileDataSource(filePath);
        // Set the data handler to the attachment 
        messageBodyPart.setDataHandler(new DataHandler(source));
        // Set the filename
        messageBodyPart.setFileName(fileName);
        // Add part two 
        multipart.addBodyPart(messageBodyPart);
        // Put parts in message
        message.setContent(multipart);

        System.out.println("Before Sending...");
        Transport.send(message);
        System.out.println("Mail Send.");
    }*/

}
