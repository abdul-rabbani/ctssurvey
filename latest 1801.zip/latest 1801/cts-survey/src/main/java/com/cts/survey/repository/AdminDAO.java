package com.cts.survey.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface AdminDAO {
	
	public int insertProjectLeads(String pLEmailIds);
	public int insertTeamMembers(String TmemailIds,String pLEmailId);
	public List<String> getProjectLeads();
	public List<String> getTeamMembers(String pLEmailId);
	
		

}
