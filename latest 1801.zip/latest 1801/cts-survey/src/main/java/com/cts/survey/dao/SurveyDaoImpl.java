package com.cts.survey.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;

@Repository
@Transactional
public class SurveyDaoImpl implements SurveyDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	final String query = "select * from ctssurvey.SURVEY_QUESTION";
	final String insertTeamLeadQuery = "INSERT INTO ctssurvey.PROJECT_LEAD_TABLE_INFO(QUESTION_ID,EMAIL_ID,VALUE) VALUES (?,?,?)";
	final String insertTMQuery = "INSERT INTO ctssurvey.TM_MEMBER_TABLE_INFO(QUESTION_ID,EMAIL_ID,VALUE) VALUES (?,?,?)";
	final String insertPartInfo ="INSERT INTO ctssurvey.PARTICIPANTS_INFO(ROLE,EMAIL_ID,PL_UNIQUE_ID,TM_UNIQUE_ID) VALUES (?,?,?,?)";
	
	@Override
	public List<Row> getQuestion() {
		// TODO Auto-generated method stub
		
		List<Row> rows = jdbcTemplate.query(query, new RowMapper() {

			@Override
			public Row mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Row row = new Row();
				row.setQuestion(rs.getString("QUESTION"));
				row.setQuestion_id(rs.getString("QUESTION_ID"));
				return row;
			}
		});
		return rows;
	}

	@Override
	public int insertData(ContactForm form, StringBuilder qstn,StringBuilder ans) {
		// TODO Auto-generated method stub

		KeyHolder holder = new GeneratedKeyHolder();
		
		if(form.getRole().equals("TL")) {
			
			jdbcTemplate.update(new PreparedStatementCreator() {           

	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTeamLeadQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2, form.getEmail());
	                ps.setString(3,ans.toString());
	                
	                return ps;
	            }
	        }, holder);
			
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),holder.getKey().longValue(),null});
			
		} else {
			
			jdbcTemplate.update(new PreparedStatementCreator() {           

	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTMQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2, form.getEmail());
	                ps.setString(3,ans.toString());
	                
	                return ps;
	            }
	        }, holder);
			
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),null,holder.getKey().longValue()});
			
			
		}

		
		
		return 0;
	}

}
