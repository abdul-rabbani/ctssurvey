package com.cts.survey.model;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

//@Entity
//@Table(name = "PROJECTLEAD_INFO")
//@EntityListeners(AuditingEntityListener.class)
public class ProjectLeadInfo implements Serializable{
	 
	  private static final long serialVersionUID = 1L;
	    @Id
	    @Column(name ="PL_ID")
	    @GeneratedValue
	    private UUID id;
	    
	    @NotBlank
	    @Column(name = "PL_EMAIL_ID")
	    @JsonProperty(value = "emailid")
	    private String emailId;

	   @Column(name = "ROLE")
	    private String role;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	  /*  @Column(name = "CREATED_DT",nullable = false, updatable = false)
	    @Temporal(TemporalType.DATE)
	    @CreatedDate
	    @JsonIgnore
	    private Date createdDate;

	    @Column(name = "MODIFIED_DT",nullable = false)
	    @Temporal(TemporalType.DATE)
	    @LastModifiedDate
	    @JsonIgnore
	    private Date modifiedDate;*/
	
	@Override
	public String toString() {
		return "ProjectLeadInfo[id="+id +"emailId="+emailId+"]";
	}

		 
		
		 
	     

	

}
